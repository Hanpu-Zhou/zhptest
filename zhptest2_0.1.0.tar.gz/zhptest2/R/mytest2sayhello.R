#' Title just the say hello function
#'
#' @return a numeric
#' @export
#'
#' @examples A 666 number
myhello <- function(){

  print("hello world")
  return(666)
}
