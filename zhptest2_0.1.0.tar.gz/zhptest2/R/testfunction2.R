#' Title my function2
#'
#' @return no
#' @export
#'
#' @examples
stillmyhello <- function(){

  print("i am happy")
}
